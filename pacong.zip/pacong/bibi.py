import requests
from lxml import etree
import re
import json


class BilibiliSpider:
    def __init__(self):
        self.home_url = "https://www.bilibili.com/"
        self.list_url = "https://api.bilibili.com/x/web-interface/newlist?rid=%d&type=0&pn=%d&ps=%d"
        self.video_url = "https://www.bilibili.com/video/av%d/"
        self.comment_url = "https://api.bilibili.com/x/v1/dm/list.so?oid=%d"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36"}

    def parse_url(self, url):
        print(url)
        return requests.get(url, headers=self.headers).content.decode()

    # === 首页爬虫 ===
    def run_home(self):
        html_str = self.parse_url(self.home_url)
        elem = etree.HTML(html_str)
        # 分组获取所有的分类 排除一些非视频的分类
        li_list = elem.xpath('//ul[@class="nav-menu"]/li[not(@class)]')
        for li in li_list:
            # 获取大分类信息
            cate_1_name = li.xpath('./a[1]/div[@class="nav-name"]/text()')[0]
            cate_1_href = "https:" + li.xpath('./a[1]/@href')[0]
            # 小分类分组
            li2_list = li.xpath('./ul[@class="sub-nav"]/li')
            for li2 in li2_list:
                # 获取小分类信息
                cate_2_name = li2.xpath('./a/span/text()')[0]
                cate_2_href = "https:" + li2.xpath('./a/@href')[0]
                print("%s-%s" % (cate_1_name, cate_2_name))
                # 调用分类页爬虫
                self.run_list(cate_1_name, cate_1_href, cate_2_name, cate_2_href)

    # === 分类页爬虫 ===
    def run_list(self, cate_1_name, cate_1_href, cate_2_name, cate_2_href):
        # 提取出tid
        html_str = self.parse_url(cate_2_href)
        json_str = re.findall(r'<script>window\.__INITIAL_STATE__=(.*?);\(function', html_str)[0]
        cate_data = json.loads(json_str)
        cate_1_tid = cate_data["config"]["tid"]
        cate_2_tid = cate_data["subConfig"]["tid"]

        # 请求列表数据ajax接口
        pn = 1  # 第几页
        ps = 10  # 每个多少个
        count = 1  # 总共有多少条
        next_url = self.list_url % (cate_2_tid, pn, ps)
        while (pn - 1) * ps < count:
            # 请求ajax接口获取视频数据
            json_str = self.parse_url(next_url)
            json_data = json.loads(json_str)

            # 请求内容页面
            content_list = []
            for v in json_data["data"]["archives"]:
                # 请求视频页面
                item = self.run_video(self.video_url % v["aid"])
                # 分类信息
                # item["cate_1_href"] = cate_1_href # 大分类链接
                item["cate_1_name"] = cate_1_name  # 大分类名称
                item["cate_2_tid"] = cate_1_tid  # 大分类id
                # item["cate_2_href"] = cate_2_href # 小分类链接
                item["cate_2_name"] = cate_2_name  # 小分类名称
                item["cate_2_tid"] = cate_2_tid  # 小分类id

                content_list.append(item)

            # 保存数据
            with open("bilibili.json", "a", encoding="utf-8") as f:
                for content in content_list:
                    f.write(json.dumps(content, ensure_ascii=False))
                    f.write("\n")

            # 分页
            pn += 1
            count = json_data["data"]["page"]["count"]
            next_url = self.list_url % (cate_2_tid, pn, ps)

    # === 视频内容页面爬虫 ===
    def run_video(self, video_url):
        # 请求视频页面
        html_str = self.parse_url(video_url)
        json_str = re.findall(r'<script>window\.__INITIAL_STATE__=(.*?);\(function', html_str)[0]
        cate_data = json.loads(json_str)
        videoData = cate_data["videoData"]

        # 视频信息
        item = {}
        item["aid"] = videoData["aid"]
        item["cid"] = videoData["cid"]
        item["title"] = videoData["title"]
        item["pic"] = videoData["pic"]

        # 请求视频页面
        item["comments"] = self.run_comment(self.comment_url % item["cid"])

        return item

    # === 评论爬虫 ===
    def run_comment(self, video_url):
        # 请求评论页面
        html_str = self.parse_url(video_url)
        elem = etree.HTML(html_str.encode())
        d_list = elem.xpath('//d/text()')
        with open("bibi.txt","a",encoding="utf-8") as f:
            for d in d_list:

                f.write(d)
                f.write("\n")
        return d_list


if __name__ == '__main__':
    # 创建爬虫对象
    spider = BilibiliSpider()
    # 首页
    spider.run_home()
# 分类
# spider.run_list("舞蹈", "https://www.bilibili.com/v/dance/", "宅舞", "https://www.bilibili.com/v/dance/otaku/")
# 视频
# print(spider.run_video("https://www.bilibili.com/video/av30720379/"))
# 评论
# print(spider.run_comment("https://api.bilibili.com/x/v1/dm/list.so?oid=53626295"))

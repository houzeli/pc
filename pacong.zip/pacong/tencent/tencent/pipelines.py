# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from  tencent.items import  TencentItem
from pymongo import MongoClient
import json

client=MongoClient()
collection=client["text"]["hr"]
class TencentPipeline(object):
    def process_item(self, item, spider):
        if isinstance(item,TencentItem):
            with open("1.txt","a",encoding="utf-8") as f:

                f.write(json.dumps(dict(item),ensure_ascii=False,indent=2))
                print("\n\n")




            collection.insert(dict(item))
        return item

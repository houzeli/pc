from selenium import webdriver
import time
driver=webdriver.Chrome()
driver.set_window_size(1920,1080)
driver.get("https://www.baidu.com")
driver.save_screenshot("./baidu1.png")

#袁术定位的方法
driver.find_element_by_id("kw").send_keys("python")
driver.find_element_by_id("su").click()
print(driver.current_url)
#print(driver.page_source)

#driver获取cookie
cookies=driver.get_cookies()
print(cookies)
print("*"*100)
cookies={i["name"]:i["value"] for i in cookies}
print(cookies)
time.sleep(3)
driver.quit()
# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from yangguang.items import YangguangItem
import requests
import re
import json
from pymongo import MongoClient
class YangguangPipeline(object):
    def open_spider(self,spider):
        client=MongoClient()
        self.collection=client["test"]["yg"]


    def process_item(self, item, spider):
        # spider.settings.get("MONGO_HOST")
        item["content"] = self.process_content(item["content"])

        if isinstance(item,YangguangItem):
            with open("1.txt", "a", encoding="utf-8") as f:
                f.write(json.dumps(dict(item), ensure_ascii=False, indent=2))
                print("\n\n")

            self.collection.insert(dict(item))
        return item



    def process_content(self,content):
        content = [re.sub(r"\xa0|\s", "", i) for i in content]
        content = [i for i in content if len(i) > 0]
        return content


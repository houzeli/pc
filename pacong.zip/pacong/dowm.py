#coding=utf-8
from gevent import monkey
monkey.patch_all()
import gevent
import urllib.request
import re


def download_img(img_name, img_url):
    """下载图片方法"""
    req = urllib.request.urlopen(img_url)
    img_content = req.read()

    with open(img_name, 'wb') as f:
        f.write(img_content)


def patch_img_url():
    """正则匹配出来所有的图片地址"""
    with open('./lol.txt', 'r', encoding='utf-8') as f:
        url_content = f.read()
    # return re.findall(r"/static/dog/\d+/\d+.jpg", url_content)
    return [re.findall(r"http://imgsrc.baidu.com/forum/pic/item/.*?.jpg", url_content)]

def main():
    img_list_spawn = []  # 定义空列表，保存所有图片下载的协程卵
    ret = patch_img_url()  # 获得所有的图片信息列表
    # 把正则匹配到的地址创建协程
    i = 1
    for img_url in ret:
        img_list_spawn.append(gevent.spawn(download_img, str(i) + '.jpg', img_url))
        i += 1
    gevent.joinall(img_list_spawn)  # joinall等待所有协程执行完毕


if __name__ == '__main__':
    main()

from selenium import webdriver
import time
driver=webdriver.Chrome()
driver.get("https://mail.qq.com/")
driver.switch_to.frame("login_frame")
driver.find_element_by_id("u").send_keys("1697736107")
driver.find_element_by_id("p").send_keys("houzeli3311")
driver.find_element_by_id("p_low_login_enable").click()
driver.find_element_by_id("login_button").click()
time.sleep(3)
driver.quit()

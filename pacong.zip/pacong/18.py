from selenium import webdriver
import time
driver=webdriver.Chrome()
driver.get("https://www.bilibili.com/v/kichiku/mad/#/all/stow")
ret=driver.find_element_by_xpath("//ul[@class='vd-list mod-2']/li//a[@class='title']").text
with open("2.txt","a",encoding="utf_8") as f:
    for r in ret:
        f.write(r)
        f.write("\n")
driver.find_element_by_xpath("//button[@class='nav-btn iconfont icon-arrowdown3']").click()
time.sleep(3)
driver.quit()
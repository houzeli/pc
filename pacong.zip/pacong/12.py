import re
import time

import requests


class NeihanSpider(object):
    def __init__(self):
        self.base_url = "http://www.neihan8.com/article/list_5_{}.html"
        self.headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"}
        self.first_pattern = re.compile(r'<div class="f18 mb20">(.*?)</div>', re.S)
        self.second_pattern = re.compile(r'<.*?>|&(.*?);|\s|　　')

    def send_request(self, url):
        time.sleep(1)
        response = requests.get(url, headers=self.headers)
        return response.content.decode("gbk")

    def write_file(self, data, page):
        with open("neihan.txt", "a", encoding="utf-8") as f:
            filename = "第" + str(page) + "页的段子\n"
            print(filename)
            f.write(filename)
            for content in data:
                second_data = self.second_pattern.sub("", content)
                f.write(second_data)
                f.write("\n\n")

    def analysis_data(self, data):
        data_list = self.first_pattern.findall(data)
        return data_list

    def run(self):
        for page in range(1, 10):
            url = self.base_url.format(page)
            data = self.send_request(url)
            second_data = self.analysis_data(data)
            self.write_file(second_data, page)


if __name__ == '__main__':
    tool = NeihanSpider()
    tool.run()

import requests
r=requests.get("https://github.com/favicon.ico")
with open("favicon.jpg","wb") as f:
    f.write(r.content)
import requests
session=requests.session()
post_url="https://mail.163.com"
post_data={"email":"houzeli0416@163.com","password":"houzeli113322"}
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}
session.post(post_url,data=post_data,headers=headers)

#在使用session进行请求登陆之后才能访问的地址
r = session.get("https://mail.163.com/js6/main.jsp?sid=EATIboCZiDZZHCNtcSZZVIDCgxrYZPOO#module=welcome.WelcomeModule%7C%7B%7D",headers=headers)

#保存页面
with open("renren1.html","w",encoding="utf-8") as f:
    f.write(r.content.decode())
import json
import requests
from pacong.parse_url import parse_url
from pprint import pprint
url="https://m.douban.com/rexxar/api/v2/subject_collection/movie_showing/items?start=0&count=8&loc_id=108288"
html_str=parse_url(url)
# print(html_str)
ret1=json.loads(html_str)
# pprint(ret1)
# print(type(ret1))
# with open("douban.json","w",encoding="utf-8") as f:
#     f.write(json.dumps(ret1,ensure_ascii=False,indent=4))
#     f.write(str(ret1))
with open("douban.json","r",encoding="utf-8") as f:
    ret2=f.read()
    ret3=json.loads(ret2)
    print(ret3)
with open("douban1.json","w",encoding="utf-8") as f:
    json.dump(ret1,f,ensure_ascii=False,indent=2)
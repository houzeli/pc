import requests

# 发送请求
response = requests.get("https://www.sina.com.cn/")

# 保存
with open("sina1.html", "w",encoding="utf-8") as f:
    f.write(response.content.decode())

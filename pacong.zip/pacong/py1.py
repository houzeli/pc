from pymongo import MongoClient

client=MongoClient()
collection=client["test"]["t251"]
# ret1=collection.insert({"name":"houzeli","age":20})
# print(ret1)

# data_list=[ {"name":"test{}".format(i)} for i in range(10)]
# collection.insert_many(data_list)
t=collection.find_one({"name":"houzeli"})
print(t)
t1=collection.find({"name":"houzeli"})
print(t1)

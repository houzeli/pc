# -*- coding: utf-8 -*-
import scrapy
from copy import deepcopy
import re
import json
class BookSpider(scrapy.Spider):
    name = 'book'
    allowed_domains = ['suning.com','suning.cn']
    start_urls = ['https://book.suning.com/']
    price_temp = "https://ds.suning.cn/ds/generalForTile/000000000%s_-010-2-%s-1--ds0000000003468.json"
    def parse(self, response):
        div_list=response.xpath('//div[@class="left-menu-container"]/div[@class="menu-list"]/div[@class="menu-item"][position() < 8]')
        sub_div_list = response.xpath( '//div[@class="left-menu-container"]/div[@class="menu-list"]/div[@class="menu-sub"][position() < 8]')
        i=0
        for div in div_list:
            item={}
            item["b_name"]=div.xpath(".//h3/a/text()").extract_first()
            item["b_href"]=div.xpath(".//h3/a/@href").extract_first()
            sub_div=sub_div_list[i]
            p_ul_list=sub_div.xpath("./div[@class='submenu-left']/*")
            for j in range(0,len(p_ul_list),2):
                item["m_name"]=p_ul_list[j].xpath("./a/text()").extract_first()
                item["m_href"]=p_ul_list[j].xpath("./a/@href").extract_first()
                ul=p_ul_list[j+1]
                li_list=ul.xpath("./li")
                for li in li_list:
                    item["s_name"] = li.xpath('./a/text()').extract_first()
                    item["s_href"] = li.xpath('./a/@href').extract_first()
                    yield scrapy.Request(
                        item["s_href"],
                        callback=self.parse_list,
                        meta={"item":deepcopy(item)}
                    )
            i+=1
    def parse_list(self,response):
        li_list=response.xpath("//div[@id='filter-results']/ul/li")
        for li in li_list:
            item=deepcopy(response.meta["item"])
            item["name"] = li.xpath('.//p[@class="sell-point"]/a/text()').extract_first()
            item["href"] = response.urljoin(li.xpath('.//p[@class="sell-point"]/a/@href').extract_first())
            item["img"] = response.urljoin(li.xpath('.//img[@class="search-loading"]/@src2').extract_first())
            shop_id,pro_id=re.findall(r"https://product\.suning\.com/(\d+)/(\d+)\.html", item["href"])[0]
            price_url=self.price_temp %(pro_id,shop_id)
            yield scrapy.Request(
                price_url,
                callback=self.parse_price,
                meta={"item":item}
            )
        currentPage = int(re.findall(r'param\.currentPage = "(\d+)";', response.body.decode())[0])
        pageNumbers = int(re.findall(r'param\.pageNumbers = "(\d+)";', response.body.decode())[0])
        if currentPage < pageNumbers:
            url = re.sub(r"\d+\.", str(currentPage + 1) + ".", item["s_href"])
            yield scrapy.Request(
                url,
                callback=self.parse_list,
                meta={"item": deepcopy(item)}
            )

    def parse_price(self, response):
        item=response.meta["item"]
        json_data=json.loads(response.body.decode())
        item["price"]=json_data["rs"][0]["price"]
        yield scrapy.Request(
            item["href"],
            callback=self.parse_detail,
            meta={"item":item}
        )

    def parse_detail(self, response):
        item = response.meta["item"]
        item["author"] = response.xpath('//span[@class="i-header" and text()="作者："]/../text()').extract_first()

        yield item

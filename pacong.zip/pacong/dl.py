import requests
proxies={
    "http":"http://117.127.0.195:8080"
}

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}
url="http://pv.sohu.com/cityjson?ie=utf-8"

response=requests.get(url,proxies=proxies)
print(response.content.decode())